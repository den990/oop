#include <iostream>
#include <string>
#include <map>

std::string GetDecode(std::string const& checkStr);
std::string HtmlDecode(std::string const& html);

#pragma once
#include <string>
#include <windows.h>
#include <fstream>

std::string ReadInputString(std::istream& input);
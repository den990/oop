#pragma once
#include <fstream>
#include <map>
#include <iostream>


void FillingWord(std::istream& input, std::map<std::string, std::string>& dictionary, std::string fileName);
